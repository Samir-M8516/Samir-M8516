<div align="center">
  <img src="./neofetch.svg" alt="username@github ~ $ neofetch" width="100%" />
</div>

<div align="center">

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://linkedin.com/in/YOUR_USERNAME)
[![Portfolio](https://img.shields.io/badge/Portfolio-39d353?style=for-the-badge&logo=vercel&logoColor=black)](https://your-portfolio.com)
[![Email](https://img.shields.io/badge/Email-0d1117?style=for-the-badge&logo=gmail&logoColor=39d353)](mailto:your.email@example.com)

</div>
